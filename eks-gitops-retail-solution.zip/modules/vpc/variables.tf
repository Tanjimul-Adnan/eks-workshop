variable "environment" { type = string }
variable "aws_region" { type = string }
variable "cluster_name" { type = string }
